<div class="col-lg-12 mt-4">
    <div class="card">

        <div class="card-header">
            <h5 class="card-title mb-0">Agregar producto</h5>
        </div><!-- end card header -->

        <div class="card-body">
            <form action="" method="POST" enctype="multipart/form-data">

                <div class="mb-3">
                    <label for="nombre_mercaderia" class="form-label">Nombre</label>
                    <input type="text" id="nombre_mercaderia" name="nombre_mercaderia" class="form-control" placeholder="Nombre del producto" required>
                </div>
                <div class="mb-3">
                    <label for="costo_mercaderia" class="form-label">Costo</label>
                    <input type="number" id="costo_mercaderia" name="costo_mercaderia" class="form-control" placeholder="Costo del producto" min="0" required>
                </div>
                
                <div class="mb-3">
                    <label for="stock_mercaderia" class="form-label"> Stock</label>
                    <input type="number" name="stock_mercaderia" class="form-control" placeholder="Ingrese el stock" min="0" required>
                </div>
      
                <div class="mb-3">
                    <label for="marca" class="form-label">Marca</label>
                    <input type="text" name="marca" class="form-control"  placeholder="Ingrese la marca" required>
                </div>
                <div class="mb-3">
                    <label for="imagen_mercaderia" class="form-label">Imagen</label>
                    <input type="file" id="imagen_mercaderia" name="imagen_mercaderia" class="form-control" accept="image/*">
                </div>
                <div class="mb-3">
                    <label for="idtipo_mercaderia" class="form-label">Tipo</label>
                    <select id="idtipo_mercaderia" name="idtipo_mercaderia" class="form-control" required>
                        <option value="" disabled selected>Seleccione un tipo</option>
                        <?php
                        $categorias = ControladorProductos::ctrObtenerCategorias();

                        if (!empty($categorias)) {
                            foreach ($categorias as $categoria) {
                                echo "<option value='" . $categoria['idtipo_mercaderia'] . "'>" .
                                        htmlspecialchars($categoria['nombre_tipo']) .
                                     "</option>";
                            }
                        } else {
                            echo "<option value='' disabled>No hay tipos disponibles</option>";
                        }
                        ?>
                    </select>
                </div>


                <?php
                $guardar = new ControladorProductos();
                $guardar->ctrAgregarProducto();
                ?>

                <button class="btn btn-info" type="submit">
                    <i class="fa-solid fa-floppy-disk"></i> Guardar
                </button>

            </form>
        </div>

    </div>
</div>
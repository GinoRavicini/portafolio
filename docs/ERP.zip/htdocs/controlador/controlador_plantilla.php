<?php
class ControladorPlantilla {
    static public function url() {
        // Detecta si estás trabajando en localhost
        if (strpos($_SERVER['HTTP_HOST'], 'localhost') !== false) {
            return 'http://localhost/aminformatica/';
        } else {
            // Dominio del hosting (ByetHost)
            return 'https://aminformatica.byethost16.com/';
        }
    }

    static public function ctrMostrarPlantilla() {
        include 'vistas/plantilla.php';
    }
}
?>
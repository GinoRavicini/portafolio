<?php

class Conexion
{
 const HOST = "sql301.byethost16.com";
 const DBNAME = "b16_40027340_aminformatica";
 const USER = "b16_40027340";
 const PASSWORD = "malena.1";
 static public function conectar()
 {
 try {
 $link = new PDO("mysql:host=" . self::HOST . ";dbname=" . self::DBNAME, self::USER,
self::PASSWORD);
 $link->exec("set names utf8");
 return $link;
 } catch (PDOException $e) {
 die("Error en la conexión a la base de datos: " . $e->getMessage());
 }
 }
}